# Formalization manifest

| Program item | Status | Lean modules | Exact boundary |
|---|---|---|---|
| A. Convention and deterministic local bound | **Kernel-proved** | `Convention.lean` | All 64 deterministic strategies are covered by decidable reduction. |
| B. Bell strategy and finite identities | **Kernel-proved core** | `BellAlgebra.lean` | Bell expansion, 2×2 reflections/projectors, and exact rational witness. The full infinite strategy is not constructed. |
| C. Effect-to-projection reduction | **Kernel-proved spectral-basis core** | `EffectReduction.lean` | Proves the response inequality from explicit finite spectral data and the scalar Halmos block. The general spectral theorem/dilation assembly is not formalized. |
| D. Operator positivity/SOS | **Kernel-proved quadratic-form core** | `OperatorCore.lean` | Exact SOS and reflected-product scalar/fibre inequality. General C*-functional calculus is not formalized. |
| E. Reflected Hellinger/quantile and rigidity | **Mixed** | `AtomicHellinger.lean`, `Rigidity.lean` | Atomic reflected Hellinger pair, adjacent-swap rearrangement, endpoint margin, stationarity and Jacobi recurrences are kernel-proved. General measure duality and quantile coupling are unformalized. |
| F. Finite dimension to finite spectral support | **Kernel-proved implication; analytic input explicit** | `SpectralSupport.lean` | Union-cardinality and final strict-gap implication are proved. Construction of spectral measures from arbitrary operators is unformalized. |
| G. Measurable quantile/Borel orbit bridge | **Conditional interface only** | `ConditionalBridge.lean` | `MeasurableQuantileOrbitBridge` names the missing construction. No instance is asserted. |
| H. Full variational/nonattainment theorem | **Not unconditionally formalized** | `ConditionalBridge.lean` | Only separately named conditional wrappers are exported. |

## Reproducibility item from the audit

The unavailable numerical scripts named in the preprint's non-load-bearing
Proposition IX.4 are not used here. Their absence is resolved by excluding that
decimal bracket from every Lean theorem. The exact rational witness above
`1/4` and exact elementary bound below `1/3` are recomputed by Lean.

## Prohibited constructs

The source contains no `sorry`, `admit`, `unsafe` declaration, custom logical
axiom, or opaque proof placeholder. CI scans for these constructs before the
build is accepted.
