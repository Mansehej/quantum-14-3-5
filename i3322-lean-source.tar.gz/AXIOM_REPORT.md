# Axiom report

`I3322/AxiomCheck.lean` runs `#print axioms` for every exported or headline
theorem. The captured output is part of `BUILD_LOG.txt`.

No project-specific logical axiom is declared. Depending on the proof and
Mathlib implementation, Lean may report the following standard foundations:

- `propext`: propositional extensionality;
- `Classical.choice`: classical choice used by finite-set and real-analysis infrastructure;
- `Quot.sound`: quotient soundness used by standard algebraic constructions.

These are standard Lean/Mathlib logical principles, not assumptions about
I3322. The conditional bridge is a structure supplied as an ordinary theorem
parameter; its fields do not enter the global environment as axioms.
