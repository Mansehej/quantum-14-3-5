import I3322.Convention
import I3322.OperatorCore
import I3322.AtomicHellinger
import I3322.Rigidity
import I3322.SpectralSupport

namespace I3322

/-- Convention mutation: the missing marginal admits a positive deterministic value. -/
example : 0 < i3322MissingAliceMarginal allOne allOne := by
  rw [missingAliceMarginal_breaks_local_bound]
  norm_num

/-- Local-bound mutation: the valid bound cannot be strengthened to `-1`. -/
example : ¬ (∀ a b : DeterministicResponse, i3322CG a b ≤ -1) := by
  intro h
  have := h allZero allZero
  rw [allZero_saturates] at this
  norm_num at this

/-- Scalar mutation: dropping the reflected-product premise permits a negative remainder. -/
example : ¬ (0 ≤ (3 / 2 : ℝ) + 3 / 2 - 4) := by
  norm_num

/-- Reflection mutation: the constant map fails the involution law. -/
example : badReflectBool (badReflectBool false) ≠ false := badReflection_not_involutive

/-- Rigidity mutation: strictness at `E<1/3` is indispensable. -/
example : endpointCoefficient (1 / 3) = 0 := endpointCoefficient_at_third

/-- Spectrum mutation: two disjoint local atoms require two union atoms. -/
example : (({0} : Finset ℕ) ∪ {1}).card >
    max ({0} : Finset ℕ).card ({1} : Finset ℕ).card := by
  decide

end I3322
