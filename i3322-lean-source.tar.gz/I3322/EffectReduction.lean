import I3322.BellAlgebra

namespace I3322

/-- The spectral best-response selector for an eigenvalue. -/
def positiveSelector (k : ℝ) : ℝ := if 0 < k then 1 else 0

/-- Pointwise best-response inequality in a diagonal spectral basis. -/
theorem effect_weight_le_projection_weight {e k : ℝ}
    (he0 : 0 ≤ e) (he1 : e ≤ 1) :
    e * k ≤ positiveSelector k * k := by
  by_cases hk : 0 < k
  · simp [positiveSelector, hk]
    nlinarith
  · have hk' : k ≤ 0 := le_of_not_gt hk
    simp [positiveSelector, hk]
    exact mul_nonpos_of_nonneg_of_nonpos he0 hk'

/-- Finite-dimensional effect-to-projection reduction after diagonalizing the response operator. -/
theorem spectral_effect_to_projection {ι : Type*} [Fintype ι]
    (e k : ι → ℝ)
    (he0 : ∀ i, 0 ≤ e i) (he1 : ∀ i, e i ≤ 1) :
    ∑ i, e i * k i ≤ ∑ i, positiveSelector (k i) * k i := by
  exact Finset.sum_le_sum fun i _ => effect_weight_le_projection_weight (he0 i) (he1 i)

/-- Equality of the selected response with the sum of positive eigenvalues. -/
theorem selected_response_eq_positive_sum {ι : Type*} [Fintype ι]
    (k : ι → ℝ) :
    ∑ i, positiveSelector (k i) * k i = ∑ i, max (k i) 0 := by
  apply Finset.sum_congr rfl
  intro i _
  by_cases hk : 0 < k i
  · simp [positiveSelector, hk, max_eq_left (le_of_lt hk)]
  · have hk' : k i ≤ 0 := le_of_not_gt hk
    simp [positiveSelector, hk, max_eq_right hk']

/-- The scalar Halmos block for an effect eigenvalue `e`. -/
def halmosBlock (e s : ℝ) : Mat2 := ⟨e, s, s, 1 - e⟩

/-- The Halmos block is a projection when `s²=e(1-e)`. -/
theorem halmosBlock_sq (e s : ℝ) (hs : s ^ 2 = e * (1 - e)) :
    halmosBlock e s * halmosBlock e s = halmosBlock e s := by
  ext <;> simp [halmosBlock, Mat2.instMulMat2] <;> nlinarith

/-- Compression to the first coordinate recovers the original effect eigenvalue. -/
theorem halmosBlock_compression (e s : ℝ) : (halmosBlock e s).a11 = e := rfl

/-- An explicit finite spectral interface for applying the reduction to a Bell best response. -/
structure SpectralBestResponseData (ι : Type*) [Fintype ι] where
  eigenvalue : ι → ℝ
  diagonalEffectWeight : ι → ℝ
  weight_nonneg : ∀ i, 0 ≤ diagonalEffectWeight i
  weight_le_one : ∀ i, diagonalEffectWeight i ≤ 1

/-- The complete diagonal best-response consequence of the spectral interface. -/
theorem SpectralBestResponseData.bestResponse {ι : Type*} [Fintype ι]
    (D : SpectralBestResponseData ι) :
    ∑ i, D.diagonalEffectWeight i * D.eigenvalue i ≤
      ∑ i, max (D.eigenvalue i) 0 := by
  calc
    ∑ i, D.diagonalEffectWeight i * D.eigenvalue i ≤
        ∑ i, positiveSelector (D.eigenvalue i) * D.eigenvalue i :=
      spectral_effect_to_projection D.diagonalEffectWeight D.eigenvalue
        D.weight_nonneg D.weight_le_one
    _ = ∑ i, max (D.eigenvalue i) 0 := selected_response_eq_positive_sum D.eigenvalue

end I3322
