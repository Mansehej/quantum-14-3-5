import I3322.OperatorCore

namespace I3322

/-- One reflected atomic pair: the Hellinger lower bound, stated using explicit square roots. -/
theorem atomic_hellinger_lower_of_roots
    {p q gp gm s up uq : ℝ}
    (hgp : 0 ≤ gp) (hgm : 0 ≤ gm) (hprod : 4 * s ^ 2 ≤ gp * gm)
    (hup : up ^ 2 = p) (huq : uq ^ 2 = q) :
    4 * s * up * uq ≤ gp * p + gm * q := by
  have h := reflected_product_quadratic hgp hgm hprod (u := up) (v := uq)
  rw [hup, huq] at h
  linarith

/-- The explicit positive-mass atomic minimizer saturates the reflected product constraint. -/
theorem atomic_hellinger_attainer_product
    {s up uq : ℝ} (hup : up ≠ 0) (huq : uq ≠ 0) :
    (2 * s * uq / up) * (2 * s * up / uq) = 4 * s ^ 2 := by
  field_simp
  ring

/-- The same explicit minimizer has exactly the Hellinger objective. -/
theorem atomic_hellinger_attainer_value
    {s up uq : ℝ} (hup : up ≠ 0) (huq : uq ≠ 0) :
    (2 * s * uq / up) * up ^ 2 + (2 * s * up / uq) * uq ^ 2 =
      4 * s * up * uq := by
  field_simp
  ring

/-- Adjacent-swap form of the countermonotone rearrangement inequality. -/
theorem countermonotone_swap {a b c d : ℝ}
    (hab : a ≤ b) (hcd : c ≤ d) :
    a * d + b * c ≤ a * c + b * d := by
  nlinarith [mul_nonneg (sub_nonneg.mpr hab) (sub_nonneg.mpr hcd)]

/-- Reflection on the two-point atomic carrier. -/
def reflectBool : Bool → Bool := Bool.not

theorem reflectBool_involution (b : Bool) : reflectBool (reflectBool b) = b := by
  cases b <;> rfl

/-- The wrong constant reflection is not an involution. -/
def badReflectBool (_ : Bool) : Bool := true

theorem badReflection_not_involutive :
    badReflectBool (badReflectBool false) ≠ false := by
  decide

end I3322
