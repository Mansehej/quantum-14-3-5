import Mathlib

namespace I3322

/-- Union support has cardinality at most the sum of the two local spectral supports. -/
theorem union_support_card_le {α : Type*} [DecidableEq α]
    (alice bob : Finset α) :
    (alice ∪ bob).card ≤ alice.card + bob.card := by
  exact Finset.card_union_le alice bob

/-- Dimension bounds on the local spectra imply the audited `d_A+d_B` scalar support bound. -/
theorem dimension_to_spectral_support {α : Type*} [DecidableEq α]
    (alice bob : Finset α) (dA dB : ℕ)
    (hA : alice.card ≤ dA) (hB : bob.card ≤ dB) :
    (alice ∪ bob).card ≤ dA + dB := by
  calc
    (alice ∪ bob).card ≤ alice.card + bob.card := union_support_card_le alice bob
    _ ≤ dA + dB := Nat.add_le_add hA hB

/-- Abstract final step of the finite-dimensional-to-finite-support reduction. -/
theorem finite_dimension_strict_from_scalar_gap
    {α : Type*} [DecidableEq α]
    (alice bob : Finset α) (dA dB : ℕ)
    (bellValue beta : ℝ) (scalarUpper : Finset α → ℝ)
    (hA : alice.card ≤ dA) (hB : bob.card ≤ dB)
    (hReduce : bellValue ≤ scalarUpper (alice ∪ bob))
    (hFiniteGap : ∀ S : Finset α, S.card ≤ dA + dB → scalarUpper S < beta) :
    bellValue < beta := by
  have hcard := dimension_to_spectral_support alice bob dA dB hA hB
  exact lt_of_le_of_lt hReduce (hFiniteGap (alice ∪ bob) hcard)

/-- Mutation control: replacing union cardinality by the maximum local cardinality is false. -/
theorem disjoint_singletons_defeat_max_support_bound :
    (({0} : Finset ℕ) ∪ {1}).card = 2 ∧
      max ({0} : Finset ℕ).card ({1} : Finset ℕ).card = 1 := by
  decide

end I3322
