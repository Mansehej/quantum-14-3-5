# I3322 Lean 4 formalization — audited algebraic core

This archive is a clean Lean 4 + Mathlib project for the audited August 2026
I3322 argument. It is deliberately split at the proof boundary that matters.

## Environment

- Lean: `leanprover/lean4:v4.32.1`
- Mathlib commit: `520045ab14e26149ee970e2e617ca04b09bde5d6`

## What is kernel-proved

The project checks the frozen Collins–Gisin convention, its exact conversion
to the Pál–Vértesi/Connor order, the deterministic local bound, the exact
noncommutative Bell expansion, finite two-by-two projective block algebra, the
exact rational strategy witness, the spectral-basis effect best response, the
Halmos block identity, the reflected-product sum-of-squares inequality, the
finite atomic Hellinger pair, the elementary countermonotone swap, the finite
rigidity recurrences, and the finite-dimensional support-counting implication.

## What is not claimed as kernel-proved

The archive does **not** claim a complete formal proof of the unrestricted
I3322 theorem. The following analytic bridge is represented only by the
explicit parameter structure `MeasurableQuantileOrbitBridge`:

1. monotone quantile matching for arbitrary probability measures;
2. measurable/Borel orbit decomposition of the partial response map;
3. disintegration with normalized orbit weights;
4. the diagonal-and-edge barycenter identity;
5. extraction of one normalizable maximizing Jacobi chain;
6. the full operator spectral theorem and functional-calculus passage from an
   arbitrary finite-dimensional Bell strategy to the scalar support data.

No custom logical axiom is introduced. Conditional theorems are ordinary Lean
implications taking these bridges as explicit hypotheses.

## Build

```bash
lake update
lake exe cache get
rm -rf .lake/build
lake build
lake env lean I3322/AxiomCheck.lean
```

The captured `BUILD_LOG.txt` in the released ZIP records the exact clean build.
See `FORMALIZATION_MANIFEST.md`, `THEOREM_MAP.md`, and `AXIOM_REPORT.md` before
citing any formalized claim.
