# Theorem map

| Audited manuscript claim | Lean theorem | Status |
|---|---|---|
| Convention concordance | `I3322.pv_eq_cg_after_swaps` | Kernel-proved |
| Local classical bound 0 | `I3322.deterministic_local_bound`, `allZero_saturates` | Kernel-proved |
| Observable Bell expansion | `I3322.bell_observable_expansion` | Kernel-proved |
| Cross-party reordering | `I3322.commute_final_cross_term` | Kernel-proved from explicit commutation hypotheses |
| Alternating 2×2 projectors | `Mat2.reflection_sq`, `effectOfReflection_sq` | Kernel-proved |
| Exact lower witness | `exact_geometric_witness_value`, `exact_geometric_witness_above_quarter` | Kernel-proved |
| Effect best response | `spectral_effect_to_projection`, `SpectralBestResponseData.bestResponse` | Kernel-proved after explicit finite diagonalization data |
| Halmos block | `halmosBlock_sq`, `halmosBlock_compression` | Kernel-proved scalar block |
| Reflected product positivity | `quadratic_nonnegative`, `reflected_product_quadratic`, `dimension_free_cross_term` | Kernel-proved quadratic-form core |
| Elementary upper algebra | `analytic_upper_factorization`, `golden_upper_lt_one_third` | Kernel-proved |
| Atomic Hellinger dual pair | `atomic_hellinger_lower_of_roots`, `atomic_hellinger_attainer_*` | Kernel-proved finite atomic core |
| Countermonotone rearrangement | `countermonotone_swap` | Kernel-proved adjacent swap only |
| Endpoint extension threshold | `endpointCoefficient_pos`, `endpointCoefficient_at_third` | Kernel-proved |
| Constant-tail propagation | `stationarity_propagates_constant_tail`, `jacobi_backward_ratio` | Kernel-proved algebraic kernel |
| Support bound | `dimension_to_spectral_support` | Kernel-proved |
| Finite-dimensional strictness from scalar gap | `finite_dimension_strict_from_scalar_gap` | Kernel-proved implication |
| Measurable orbit extraction | `MeasurableQuantileOrbitBridge` | Conditional interface, no instance |
| Infinite maximizing chain | `conditional_infinite_maximizing_chain` | Conditional |
| No finite-dimensional attainer | `conditional_no_finite_dimensional_attainer` | Conditional |
